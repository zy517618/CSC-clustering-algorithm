function [IdRemainPoints,RemainedLabel,Increased]=KernalsExtend(X,ED,IdCirPoints,IdSortRadius,IdRemainPoints,RemainedLabel,ClusterSetsTemp,MergeFindSet,ShowF)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: skeleton extend
%% Input
% X: data matrix
% ED:the Euclidean distance between different point of data
% IdCirPoints: the first n nearest points of every point
% IdSortRadius: the ID of the first n nearest points
% IdRemainPoints: the ID of remaining points
% RemainedLabel:   the label of remaining points
% ClusterSetsTemp:  the cluster skeletons of current set 
% MergeFindSet: union-find data structure
% ShowF: show the result or not
%% Output
% IdRemainPoints: average radius of points
% RemainedLabel: all the center points
% Increased: there is points being extended or not
%%

KernalPoints=nonzeros(ClusterSetsTemp)';
for i=IdRemainPoints
    MergeFindSet(i)=i;
end
AllPoint=(1:size(X,1));
OtherPoints=setdiff(AllPoint,IdRemainPoints);
%sort the remained points by radius
[~,IdRemainTemp1]=setdiff(IdSortRadius,OtherPoints);
IdRemainTemp=IdSortRadius(sort(IdRemainTemp1));%keep the order indifferent
%Assign remained points to clusters in descending order of point density 
ExtendPoints=[];
Increased=0;
%
%assign the point to the point which is the nearest point in KernalPoints 
MaxDis=max(max(ED));
for i=IdRemainTemp'
   MinDis=MaxDis;
   MinId=0;
   
   for j=IdCirPoints(i,:)
      if ismember(j,KernalPoints)
         if ED(i,j)<MinDis
            MinDis=ED(i,j); 
            MinId=j;
         end
      end
   end
   if MinDis~=MaxDis 
         MergeFindSet(i)=MinId;
         IdRemainPoints=setdiff(IdRemainPoints,i);
         RemainedLabel(i)=0;
         ExtendPoints=[ExtendPoints,i];
         KernalPoints=[KernalPoints,i];
         Increased=1;
   end
end


%assign the point to the point which is the most clustercenter in the circle
% for i=IdRemainTemp'
%    TempCluster=[];
%    for j=IdCirPoints(i,:)
%        k=findp(j,MergeFindSet);
%        if ismember(k,ClusterCentersTemp)
%           TempCluster=[TempCluster,k]; 
%        end
%    end
%    if ~isempty(TempCluster)
%        TempCluster=[TempCluster,max(TempCluster)+1]; %For cases where there is only one element
%        uniqueCluster=unique(TempCluster);
%        ClusterCount = hist(TempCluster,unique(TempCluster));
%        [~,id]=sort(ClusterCount,'descend');
%        % merge two sets
%        %if ismember(uniqueCluster(id(1)),ClusterCentersTemp) %root must be a clustercenter
%          MergeFindSet(i)=uniqueCluster(id(1));
%          IdRemainPoints=setdiff(IdRemainPoints,i);
%          RemainedLabel(i)=0;
%          ExtendPoints=[ExtendPoints,i];
%          Increased=1;
%        %end
%    end
% end

%show figure
if  ShowF  
    figure;
    scatter(X(OtherPoints,1), X(OtherPoints,2),20,'wo');
    hold on
    scatter(X(ExtendPoints,1), X(ExtendPoints,2), 20,'ro');
    hold on
    scatter(X(KernalPoints,1), X(KernalPoints,2),20,'ro');
    hold on


    %title('kernal points graph');

    for i = [KernalPoints,ExtendPoints]
      if MergeFindSet(i)~=0
          i1=i;
          j1=MergeFindSet(i);
            plot([X(i1,1),X(j1,1)], [X(i1,2),X(j1,2)], '-r', 'LineWidth',1);       
      end
    end
    hold on;
    axis equal;
    axis off;
    %title('kernal graph');
    %hold off;
    %axis equal;
    %axis off;
end
