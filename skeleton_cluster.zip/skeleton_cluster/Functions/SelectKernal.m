function [IdNewKernalPoints,IdRemainPoints,RemainedLabel,AveRadius] = SelectKernal(X,ED,EveryRadius,RemainedLabel,IdRemainPoints,CirDen,ShowF)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: select core points in the current set.
%% Input
% X: data matrix
% ED:the Euclidean distance between different point of data
% EveryRadius: average radius of points
% RemainedLabel: the label of remaining points
% IdRemainPoints: the ID of remaining points
% CirDen: the parameter about the circle density of the point
% ShowF
%% Output
% IdNewKernalPoints: the ID of newremaining points
% IdRemainPoints: the ID of remaining points
% RemainedLabel:the label of remaining points
% AveRadius: average radius of points

%%
n=size(ED,1);
XX=(1:n);
IdRemainPointsShow=setdiff(XX,IdRemainPoints); %only show
%Convert ID 
%IdConvert = bsxfun(@plus,(IdRadiusCircle-1)*n,(1:n).');
%Computer the average radius of all points 
SelectRadius=EveryRadius(IdRemainPoints);
SortRadius=sort(SelectRadius);
AveRadius=SortRadius(round(size(IdRemainPoints,2)/2));
%SelectRadius=EveryRadius(IdRemainPoints,1);
%AveRadius=sum(SelectRadius)/size(SelectRadius,1);
%Extract the kernal points
Slabel=EveryRadius<AveRadius;
Slabeltemp=RemainedLabel.*Slabel;
IdNewKernalPoints=find(Slabeltemp>0);

%get the remaining points
Slabel=1-Slabel;
RemainedLabel=RemainedLabel.*Slabel;
AllPoints=(1:n)';
IdRemainPoints=find(AllPoints.*RemainedLabel>0)';

%if show the figure or not

if ShowF
    figure;
    scatter(X(IdRemainPointsShow,1), X(IdRemainPointsShow,2), 20,'ko');
    hold on
    scatter(X(IdNewKernalPoints,1), X(IdNewKernalPoints,2), 20,'ko');
    hold on
    scatter(X(IdRemainPoints,1), X(IdRemainPoints,2), 20,'ko');
    hold on
    %title('kernal points graph');
    hold off;
    axis equal;
    axis off;
    %for i=(1:size(X,1))
     %  text(X(i,1),X(i,2),num2str(i));
    %end
end