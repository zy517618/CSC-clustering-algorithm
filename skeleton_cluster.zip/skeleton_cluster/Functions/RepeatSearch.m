function [IdCirPoints,IdSortRadius,AveRadius,ClusterCenters,ClusterSets,MergeFindSet]=RepeatSearch(X,ED,CirDen)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: find out all clusters skeletons
%% Input
% X: data matrix
% ED:the Euclidean distance between different point of data
% CirDen: the parameter about the circle density of the point
%% Output
% IdCirPoints: the first n nearest points of every point
% IdSortRadius: the ID of the first n nearest points
% AveRadius: average radius of points
% ClusterCenters: cluster centers
% ClusterSets: clusterset
% MergeFindSet: union-find data structure
%%
  IdRemainPoints=(1:size(X,1));
  [~,ED_Sort_Id] = sort(ED,2);
  %Extracts the ID of the first n nearest points of every point
  IdCirPoints=ED_Sort_Id(:,2:CirDen+1);
  %Extracts the ID of the nth nearest points
  IdRadiusCircle=ED_Sort_Id(:,CirDen+1);
  %Convert ID 
  n=size(X,1);
  IdConvert = bsxfun(@plus,(IdRadiusCircle-1)*n,(1:n).');
  %Computer the  radius of every point 
  EveryRadius=ED(IdConvert);
  %[SortRadius,~]=sort(EveryRadius);
  %AveRadius=SortRadius(round(n/2));
  [~,IdSortRadius]=sort(EveryRadius);
  RemainedLabel=1-zeros(n,1);
  %save clutercenters and clustersets 
  ClusterCenters=[];
  ClusterSets=[];
  MergeFindSet=zeros(1,n);
  Increased=1;
  while size(IdRemainPoints,2)>CirDen && Increased
      %select the kernal points;
      [IdNewKernalPoints,IdRemainPoints,RemainedLabel,AveRadius] = SelectKernal(X,ED,EveryRadius,RemainedLabel,IdRemainPoints,CirDen,0);
      %form cluster Skeletons by MergeFindSet
      MergeFindSetTemp=LinkKernals(X,IdRemainPoints,EveryRadius,IdCirPoints,IdNewKernalPoints,0);
      %search clutercenters and clustersets from IdRemainPoints
      [ClusterCentersTemp,ClusterSetsTemp]=Clusters(CirDen,MergeFindSetTemp);
      %add up clustercenters and clustersets
      ClusterCenters=[ClusterCenters,ClusterCentersTemp];
      ClusterSets=[ClusterSets;ClusterSetsTemp];
      %add up MergeFindSet of different ClusterSets
      AllKernal=nonzeros(ClusterSetsTemp);
      for i=AllKernal
          MergeFindSet(i)=MergeFindSetTemp(i);
      end
      %Extend points from skeleton
      [IdRemainPoints,RemainedLabel,Increased] = KernalsExtend(X,ED,IdCirPoints,IdSortRadius,IdRemainPoints,RemainedLabel,ClusterSetsTemp,MergeFindSet,0);
      
  end
end

