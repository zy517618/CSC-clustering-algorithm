function [ClusterCentersTemp,ClusterSetsTemp]=Clusters(CirDen,MergeFindSet)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: search clutercenters and clustersets from IdRemainPoints.
%% Input
% CirDen: the parameter about the circle density of the point
% MergeFindSet: union-find data structure
%% Output
% ClusterCentersTemp: the center points
% ClusterSetsTemp:  cluster sets


%%
n=size(MergeFindSet,2);
ClusterCentersTemp=[];
ClusterCentersTemp1=[];
ClusterSetsTemp =[];
for i=(1:n)
   if MergeFindSet(i)==i
       ClusterCentersTemp1=[ClusterCentersTemp1,i];
   end
end
for i=ClusterCentersTemp1
    ClusterSet=[];
    for j=1:n
        if i==findp(j,MergeFindSet)
            ClusterSet=[ClusterSet,j];
        end
    end
    ClusterSet=[ClusterSet,zeros(1,n-length(ClusterSet))];
    ClusterSetsTemp=[ClusterSetsTemp;ClusterSet];
    ClusterCentersTemp=[ClusterCentersTemp,i]; 
end