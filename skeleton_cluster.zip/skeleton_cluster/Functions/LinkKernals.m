function MergeFindSet=LinkKernals(X,IdRemainPoints,EveryRadius,IdCirPoints,IdNewKernalPoints,ShowF)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: by union-find function,link all the core points
%% Input
% X: data matrix
% IdRemainPoints: the ID of remaining points
% EveryRadius: average radius of points
% IdCirPoints: the first n nearest points of every point
% IdNewKernalPoints: the ID of new core points being found
% ShowF: show the result or not
%% Output
% MergeFindSet: union-find data structure
%%
[n,m] = size(IdCirPoints);
k=size(IdNewKernalPoints);
labels=zeros(n,n);
MergeFindSet=zeros(1,n);
MergeFindSet(IdNewKernalPoints)=IdNewKernalPoints;
for i=IdNewKernalPoints'
    for j=IdCirPoints(i,:)
           if labels(i,j)==0
              parenti=findp(i,MergeFindSet);
              parentj=findp(j,MergeFindSet);
%merge and find set,merge
              if parenti~=parentj && (parenti~=0 && parentj~=0)
                if EveryRadius(parenti)>EveryRadius(parentj)
                      MergeFindSet(parenti)=parentj;
                else
                      MergeFindSet(parentj)=parenti;
                end
                labels(i,j)=1;
              end
          end
    end
end
%show figure
if  ShowF  
    AllPoints=(1:n)';
    OnePoints=setdiff(AllPoints,IdRemainPoints);
    OtherPoints=setdiff(IdRemainPoints,IdNewKernalPoints);
    figure;
    scatter(X(IdRemainPoints,1), X(IdRemainPoints,2), 20,'ko');
    hold on
    scatter(X(OnePoints,1), X(OnePoints,2), 20,'wo');
    hold on
    scatter(X(IdNewKernalPoints,1), X(IdNewKernalPoints,2), 20,'ro');
    hold on

    %title('kernal points graph');
    hold on;
    axis equal;
    axis off;
    for i = 1:n
      if MergeFindSet(i)~=0
          i1=i;
          j1=MergeFindSet(i);
            plot([X(i1,1),X(j1,1)], [X(i1,2),X(j1,2)], '-r', 'LineWidth',1);
        
      end
    end
    %title('kernal graph');
    %hold off;
    %axis equal;
    %axis off;
end

