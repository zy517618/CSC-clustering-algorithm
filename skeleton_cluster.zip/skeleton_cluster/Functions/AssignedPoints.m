function [MergeFindSet,IdRemainTemp]=AssignedPoints(X,ED,IdCirPoints,IdSortRadius,AveRadius,ClusterCenters,ClusterSets,MergeFindSet,AssignNoise,ShowF)
% Written by LiJun Zhu (zhulijun@yeah.net). 
%% the function of RepeatSearch is: assign the remaining points
%% Input
% X: data matrix
% ED:the Euclidean distance between different point of data
% IdCirPoints: the first n nearest points of every point
% IdSortRadius: the ID of the first n nearest points
% AveRadius: average radius of points
% ClusterCenters: all the center points
% ClusterSets:  all cluster sets
% MergeFindSet: union-find data structure
% AssignNoise: assing noise or not
% ShowF: show the result or not
%% Output
% IdRemainTemp: the points  not being assigned 
% MergeFindSet: union-find data structure
%%


IdKernalPoints=nonzeros(ClusterSets)';%convert all kernal points into one dimension vector
%sort the remained points by radius
[RemainTemp,IdRemainTemp]=setdiff(IdSortRadius,IdKernalPoints);
for i=RemainTemp
    MergeFindSet(i)=i;
end
IdRemainTemp=IdSortRadius(sort(IdRemainTemp));%keep the order indifferent

%Assign remained points to clusters in descending order of point density
symble=1;
IdRemainTemp=IdRemainTemp';
maxmatrix=max(max(ED))+1;
%Points with high density may be post-connected, thus requiring multiple cycles
while ~isempty(IdRemainTemp)&&symble==1
  symble=0;
  DeletePoints=[];
  for i=IdRemainTemp
     minvalue=maxmatrix;
     for j=IdCirPoints(i,:)
         if ED(i,j)<minvalue && ismember(j,IdKernalPoints)&&ED(i,j)<AveRadius
             minvalue=ED(i,j);
             minid=j;
         end
     end
     if minvalue~=maxmatrix
       MergeFindSet(i)=minid;
       DeletePoints=[DeletePoints,i];
       IdKernalPoints=[IdKernalPoints,i];
       symble=1;
     end    
  end
  [~,id]=setdiff(IdRemainTemp,DeletePoints);
  IdRemainTemp=IdRemainTemp(sort(id));
  %IdRemainTemp=IdRemainTemp1;
end
% assign noise points
if AssignNoise
  if ~isempty(IdRemainTemp)
     for i=IdRemainTemp
        minvalue=maxmatrix;
        for j=IdKernalPoints
            if ED(i,j)<minvalue
               minvalue=ED(i,j);
               minid=j;
            end
        end
        if minvalue~=maxmatrix
           MergeFindSet(i)=minid;
           IdKernalPoints=[IdKernalPoints,i];
        end    
     end  
  end
  IdRemainTemp=[];
end


%show figure
n=size(X,1);
kk=1;
if  ShowF  
    figure;
    %show the all points
    for i=ClusterCenters
        ClusterId=[];
        for j=(1:n)
            k=findp(j,MergeFindSet);
            if i==k
              ClusterId=[ClusterId,j];
            end
        end
        scatter(X(ClusterId,1), X(ClusterId,2), 20,'filled','o');
        hold on
        kk=kk+1;

%        for ii = 1:n
%          if MergeFindSet(ii)~=0
%             i1=ii;
%             j1=MergeFindSet(ii);
%             if i==findp(i1,MergeFindSet)
%               plot([X(i1,1),X(j1,1)], [X(i1,2),X(j1,2)], '-r', 'LineWidth',1);
%             else
%               plot([X(i1,1),X(j1,1)], [X(i1,2),X(j1,2)], '-b', 'LineWidth',1);  
%             end 
%          end
%        end
       hold on;
       axis equal;
       axis off;
    end

    %show the noise
    if AssignNoise==0
      scatter(X(IdRemainTemp,1), X(IdRemainTemp,2), 50,'k','+');
      hold on
    end 
    %title('kernal points graph');

end



