%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Written by LiJun Zhu (zhulijun@yeah.net).
%%
%CSC is a new clustering algorithm which is applied to detect cluster with 
%various density,Irregular shape and multi-center by skeleton extending and 
% union-find data structrue.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; close all; clc; 
addpath(genpath(pwd));              % set path
addpath('D:\mytestACC\skeleton_cluster\Eval_matlab');
temp=load('d:\data\zoo.txt');
X=temp(:,2:17);
Y=temp(:,1);
sumtime=0;
num=0;
k=-0.3; % the only parameter in CSC algorithm
[labels,IdRemainTemp] = SkeletonExtend(X,k); %return clustering results.
Y(IdRemainTemp)=[];
[~,ari,nmi] = evaluation(Y, labels'); %evaluate function
fprintf("ari=%f,nmi=%f\n",ari,nmi);



