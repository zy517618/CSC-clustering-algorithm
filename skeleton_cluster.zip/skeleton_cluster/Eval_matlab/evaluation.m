%
function [RI,ARI,NMI] = evaluation(real, pred)
   [RI,ARI]=ri_ari(real, pred);
   NMI=nm(real, pred);
  
