%merge and find set;
% find
function parenti=findp(i,MergeFindSet)
   if MergeFindSet(i)==0;
       parenti=0;
   else
       while MergeFindSet(i)~=i
         i=MergeFindSet(i);
       end
       parenti=i;
   end


