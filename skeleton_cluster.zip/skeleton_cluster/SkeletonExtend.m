function [labels,IdRemainTemp] = SkeletonExtend(X,k)

% Written by LiJun Zhu (zhulijun@yeah.net).

%% Input
% X: data matrix
% k: the threshold 

%% Output
% labels: clustering labels

%% 
numSamp= size(X,1);
% computer the Euclidean distance between different point of data
ED = EucDistance(X',X');
%ED=X;  % face identify
%% 
%set the parameter about the circle density of the point
CirDen=round(sqrt(numSamp)*(1+k));

%% repeat SelectKernal,LinkKernals,Clusters and skeletonExtend until all cluster are found.
[IdCirPoints,IdSortRadius,AveRadius,ClusterCenters,ClusterSets,MergeFindSet]=RepeatSearch(X,ED,CirDen);

%% assigned other remained points to different Cluster skeletons
[MergeFindSet,IdRemainTemp]=AssignedPoints(X,ED,IdCirPoints,IdSortRadius,AveRadius,ClusterCenters,ClusterSets,MergeFindSet,1,0);
labels=[];
k=0;
for i=(1:numSamp)
  labels=[labels,find(ClusterCenters==findp(i,MergeFindSet))];
end


